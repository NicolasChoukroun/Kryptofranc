KryptoFranc Core integration/staging tree
=====================================

https://kryptofranc.com

This folder is the end result after modifications of all scripts. This is where KryptoFranc is compiled.
