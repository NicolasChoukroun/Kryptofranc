<?php
$ip="62.43.197.144";
$info = geoip_record_by_name($ip);
if ($info) {
	print "country=".geoip_database_info(GEOIP_COUNTRY_EDITION)."<br>";
	print "org=".geoip_database_info(GEOIP_ORG_EDITION)."<br>";
	print "isp=".geoip_database_info(GEOIP_ISP_EDITION )."<br>";	

	print "city=".geoip_database_info(GEOIP_CITY_EDITION_REV1 )."<br>";
	

	print "asnum=".geoip_database_info(GEOIP_ASNUM_EDITION  )."<br>";
	print "netspeed=".geoip_database_info(GEOIP_NETSPEED_EDITION   )."<br>";
	print "domain=".geoip_database_info(GEOIP_DOMAIN_EDITION)."<br>";

		
	
	
    print_r($info);
	print "org =".geoip_org_by_name($ip);
	print "isp =".geoip_isp_by_name($ip);
}
?>