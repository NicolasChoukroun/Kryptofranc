<?php
if( isset( $_SERVER[ 'HTTP_X_ORIGINAL_URL' ] ) )
{
	$_SERVER[ 'REQUEST_URI' ] = $_SERVER[ 'HTTP_X_ORIGINAL_URL' ];
}
?>